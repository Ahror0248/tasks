$(document).ready(function () {
  let input = $("input[name=input]");
  if (input[(val = 0)]) {
    $(".num7").click(function () {
      let prev = input.val();
      let num7Val = $(".num7").val();
      input.val(` ${prev} ${num7Val}`);
    });

    $(".num8").click(function () {
      let prev = input.val();
      let num8Val = $(".num8").val();
      input.val(`${prev} ${num8Val}`);
    });

    $(".num9").click(function () {
      let prev = input.val();
      let num9Val = $(".num9").val();
      input.val(` ${prev} ${num9Val}`);
    });

    $(".num6").click(function () {
      let prev = input.val();
      let num6Val = $(".num6").val();
      input.val(` ${prev} ${num6Val}`);
    });

    $(".num5").click(function () {
      let prev = input.val();
      let num8Val = $(".num5").val();
      input.val(` ${prev} ${num8Val}`);
    });

    $(".num4").click(function () {
      let prev = input.val();
      let num8Val = $(".num4").val();
      input.val(` ${prev} ${num8Val}`);
    });

    $(".num3").click(function () {
      let prev = input.val();
      let num8Val = $(".num3").val();
      input.val(`${prev} ${num8Val}`);
    });

    $(".num2").click(function () {
      let prev = input.val();
      let num8Val = $(".num2").val();
      input.val(`${prev} ${num8Val}`);
    });

    $(".num1").click(function () {
      let prev = input.val();
      let num8Val = $(".num1").val();
      input.val(` ${prev} ${num8Val}`);
    });

    $(".num0").click(function () {
      let prev = input.val();
      let num8Val = $(".num0").val();
      input.val(`${prev} ${num8Val}`);
    });

    $(".plus").on({
      click: function () {
        let prev = input.val();
        let plusVal = $(".plus").val();
        input.val(` ${prev}  ${plusVal} `);
      },
    });

    $(".equal").on({
      click: function () {
        let prev = input.val();
        let equalVal = $(".equal").val(`${prev}`);
        input.val(`${equalVal} `);
      },
    });

    $(".reset").click(function () {
      input.val("0");
    });
  }
});
