$(document).ready(function () {
  $(".clickable").click(function () {
    let arr = [
      "./binocular.jpeg",
      "./book.jpg",
      "./lion.jpg",
      "./national.jpg",
      "./nature.jpg",
      "./sunset.jpg",
      './wood.jpg'
    ];

    $(".forImg1").prepend(`<img src="${arr[0]}" width="100%" alt=""/>`);
    $(".forImg2").prepend(`<img src="${arr[1]}" width="100%" alt=""/>`);
    $(".forImg3").prepend(`<img src="${arr[2]}" width="100%" alt=""/>`);
    $(".forImg4").prepend(`<img src="${arr[3]}" width="100%" alt=""/>`);
    $(".forImg5").prepend(`<img src="${arr[4]}" width="100%" alt=""/>`);
    $(".forImg6").prepend(`<img src="${arr[6]}" width="100%" alt=""/>`);
 
    



  });
});
